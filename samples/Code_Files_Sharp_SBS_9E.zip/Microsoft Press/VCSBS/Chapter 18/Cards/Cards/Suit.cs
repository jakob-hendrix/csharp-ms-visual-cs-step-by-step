﻿
namespace Cards
{
    enum Suit { Clubs, Diamonds, Hearts, Spades }
}